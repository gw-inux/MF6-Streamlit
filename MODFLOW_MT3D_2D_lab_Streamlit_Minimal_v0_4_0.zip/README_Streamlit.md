# MT3D 2D/3D — Streamlit Community Cloud v0.4.0

Copy `MODFLOW_MT3D_2D_lab/` into the same repository level as your existing `MODFLOW_MT3D_lab/` and shared `bin/` folder. The separate package name prevents collisions with the 1D lab. No existing files need to be overwritten.

Set **Main file path** to `MODFLOW_MT3D_2D_lab/streamlit_app.py` and choose **Python 3.12**. This entry point has its own `requirements.txt`, so your 1D dependency file need not change. The optional root launcher is `MODFLOW_MT3D_2D_lab.py`; use the folder entry point for Cloud to select this app's dependencies.

The package contains the same interface, all ten languages, fonts, equations, model and plotting code as the full review version. It omits tests, reports and executables. Shared Linux x86-64 executables must be available:

| Program | Standard repository path | Also accepted names |
|---|---|---|
| MODFLOW-2005 | `bin/mf2005` | `mf2005_MT3D`, `MODFLOW-2005_64`, `MODFLOW2005`, `MODFLOW-2005` |
| MT3DMS | `bin/mt3dms` | `mt3dms5b`, `MT3DMS_64`, `MT3DMS5`, `MT3DMS` |
| MODPATH 7 | `bin/mp7` | `mpath7`, `MODPATH7`, `modpath7` |

`bin/linux/`, `common/` and `common/bin/` in the app folder or its parent are also searched. `TRANSPORT_LAB_BIN` can specify another folder; individual overrides are `TRANSPORT_LAB_MF2005`, `TRANSPORT_LAB_MT3DMS` and `TRANSPORT_LAB_MP7`. Linux execute permission is restored where permitted. Windows `.exe` binaries cannot run on Community Cloud. If your shared folder only has the two 1D solvers, add MODPATH 7 or disable **MODPATH particle comparison**.

Local check from the repository root:

```bash
python -m pip install -r MODFLOW_MT3D_2D_lab/requirements.txt
streamlit run MODFLOW_MT3D_2D_lab/streamlit_app.py
```

The Cloud layout was tested locally with shared native executables and the Streamlit test runner. It has not been deployed to your account. Cloud runtime and memory limits still depend on the host and chosen expert settings.

[Streamlit file organization](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/file-organization) · [Dependency lookup](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/app-dependencies)
